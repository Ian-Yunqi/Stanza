const fs = require("fs");

const css = fs.readFileSync("D:/tool/suibian/shufang/css/style.css", "utf-8");
const books = JSON.parse(fs.readFileSync("D:/tool/suibian/shufang/data/books.json", "utf-8"));
const bodyMatch = fs.readFileSync("D:/tool/suibian/shufang/index.html", "utf-8").match(/<body>([\s\S]*)<\/body>/);
const body = bodyMatch[1].replace(/<script[\s\S]*?<\/script>/g, "");

const js = `
/* ===== storage ===== */
const SEEN_KEY = "shufang-seen";
const DOSE_PREFIX = "shufang-dose-";
function isStorageAvailable() {
    try { const t = "__test__"; localStorage.setItem(t, t); localStorage.removeItem(t); return true; }
    catch (e) { return false; }
}
function getSeenBooks() {
    if (!isStorageAvailable()) return [];
    try { const d = localStorage.getItem(SEEN_KEY); return d ? JSON.parse(d) : []; }
    catch (e) { return []; }
}
function pushSeenBook(id) {
    if (!isStorageAvailable()) return;
    try {
        let seen = getSeenBooks();
        if (!seen.includes(id)) { seen.push(id); if (seen.length > 5) seen.shift(); localStorage.setItem(SEEN_KEY, JSON.stringify(seen)); }
    } catch (e) {}
}
function getDailyDose(dateStr) {
    if (!isStorageAvailable()) return null;
    return localStorage.getItem(DOSE_PREFIX + dateStr);
}
function setDailyDose(dateStr, id) {
    if (!isStorageAvailable()) return;
    try { localStorage.setItem(DOSE_PREFIX + dateStr, id); cleanOldDoses(dateStr); } catch (e) {}
}
function cleanOldDoses(currentDateStr) {
    const today = new Date(currentDateStr).getTime();
    for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key && key.startsWith(DOSE_PREFIX)) {
            const kt = new Date(key.replace(DOSE_PREFIX, "")).getTime();
            if (today - kt > 7 * 24 * 60 * 60 * 1000) localStorage.removeItem(key);
        }
    }
}

/* ===== matcher ===== */
function matchBook(tag, books, seenIds) {
    if (tag === "daily") {
        const fresh = books.filter(b => !seenIds.includes(b.id));
        const pool = fresh.length ? fresh : books;
        return { book: pool[Math.floor(Math.random() * pool.length)], degraded: false };
    }
    let pool = books.filter(b => b.tags.primary === tag);
    let degraded = false;
    if (!pool.length || pool.every(b => seenIds.includes(b.id))) {
        const sp = books.filter(b => b.tags.secondary && b.tags.secondary.includes(tag));
        if (sp.length) { pool = sp; degraded = true; }
    }
    const fresh = pool.filter(b => !seenIds.includes(b.id));
    const candidates = fresh.length ? fresh : pool;
    return { book: candidates[Math.floor(Math.random() * candidates.length)], degraded };
}

/* ===== observer ===== */
let _quoteObserver = null;
function initQuoteObserver() {
    if (_quoteObserver) _quoteObserver.disconnect();
    _quoteObserver = new IntersectionObserver((entries, obs) => {
        entries.forEach(function(entry) {
            if (entry.isIntersecting) {
                entry.target.style.opacity = "1";
                entry.target.style.transition = "opacity 0.6s ease";
                obs.unobserve(entry.target);
            }
        });
    }, { threshold: 0.15, rootMargin: "0px 0px -50px 0px" });
    document.querySelectorAll(".quote-item").forEach(function(el) { _quoteObserver.observe(el); });
}

/* ===== render ===== */
function renderHome() {
    var dv = document.getElementById("dose-view");
    var hv = document.getElementById("home-view");
    dv.classList.remove("active");
    setTimeout(function() {
        dv.classList.add("hidden");
        hv.classList.remove("hidden");
        void hv.offsetWidth;
        hv.classList.add("active");
    }, 400);
}

function renderDose(bookInfo, currentTag) {
    var book = bookInfo.book;
    var degraded = bookInfo.degraded;
    var hintEl = document.getElementById("degraded-hint");
    if (degraded && currentTag !== "daily") {
        hintEl.textContent = "本日\\"" + currentTag + "\\"之药已尽，以下为相近之方";
        hintEl.classList.remove("hidden");
    } else {
        hintEl.classList.add("hidden");
    }
    document.getElementById("render-id").textContent = book.id + " ·";
    var guideHtml = book.guide.split("\\n").filter(function(p) { return p.trim(); }).map(function(p) { return "<p>" + escapeHtml(p) + "</p>"; }).join("");
    document.getElementById("render-guide").innerHTML = guideHtml;

    var qHtml = "<div class=\\"book-meta\\"><div class=\\"book-title\\">" + escapeHtml(book.title) + "</div><div class=\\"book-author\\">" + escapeHtml(book.author) + "</div></div><div class=\\"quote-divider\\"></div>";
    book.quotes.forEach(function(q) {
        qHtml += "<div class=\\"quote-item\\"><div class=\\"quote-text\\">" + escapeHtml(q) + "</div><div class=\\"quote-divider\\"></div></div>";
    });
    qHtml += "<div class=\\"extras-box\\"><div>" + escapeHtml(book.extras.availability) + "</div><div style=\\"margin-top: 8px;\\">如果你喜欢：" + escapeHtml(book.extras.ifYouLike) + "</div></div><div class=\\"end-marker\\">□</div>";
    document.getElementById("render-quotes").innerHTML = qHtml;

    var hv = document.getElementById("home-view");
    var dv = document.getElementById("dose-view");
    hv.classList.remove("active");
    window.scrollTo(0, 0);

    setTimeout(function() {
        hv.classList.add("hidden");
        dv.classList.remove("hidden");
        var gh = document.querySelector(".guide-section").offsetHeight;
        var arrow = document.getElementById("scroll-arrow");
        arrow.style.display = (gh < window.innerHeight * 0.8) ? "none" : "block";
        document.getElementById("footer-actions").classList.remove("hidden");
        void dv.offsetWidth;
        dv.classList.add("active");
        initQuoteObserver();
    }, 400);
}

function escapeHtml(text) {
    var div = document.createElement("div");
    div.textContent = text;
    return div.innerHTML;
}

/* ===== router ===== */
var appBooks = [];

function initRouter(books) {
    appBooks = books;
    handleUrlChange();
    window.addEventListener("popstate", handleUrlChange);
}

function navigateToTag(tag) {
    var url = new URL(window.location);
    url.searchParams.set("tag", tag);
    window.history.pushState({}, "", url);
    handleUrlChange();
}

function goHome() {
    var url = new URL(window.location);
    url.searchParams.delete("tag");
    window.history.pushState({}, "", url);
    handleUrlChange();
}

function handleUrlChange() {
    var params = new URLSearchParams(window.location.search);
    var tag = params.get("tag");
    if (!tag) { renderHome(); return; }
    var matchResult;
    if (tag === "daily") {
        var today = new Date().toLocaleDateString("zh-CN");
        var savedId = getDailyDose(today);
        if (savedId) {
            var b = appBooks.find(function(x) { return x.id === savedId; });
            matchResult = b ? { book: b, degraded: false } : null;
        }
        if (!matchResult) {
            matchResult = matchBook("daily", appBooks, getSeenBooks());
            if (matchResult.book) setDailyDose(today, matchResult.book.id);
        }
    } else {
        matchResult = matchBook(tag, appBooks, getSeenBooks());
    }
    if (matchResult && matchResult.book) {
        pushSeenBook(matchResult.book.id);
        renderDose(matchResult, tag);
    } else {
        goHome();
    }
}

/* ===== main ===== */
document.addEventListener("DOMContentLoaded", function() {
    try {
        var books = BOOKS;
        document.querySelectorAll(".tag-btn").forEach(function(btn) {
            btn.addEventListener("click", function() { navigateToTag(btn.dataset.tag); });
        });
        document.querySelector(".daily-btn").addEventListener("click", function() { navigateToTag("daily"); });
        document.getElementById("nav-back").addEventListener("click", goHome);
        document.getElementById("nav-home").addEventListener("click", goHome);
        document.getElementById("nav-next").addEventListener("click", function() {
            var ct = new URLSearchParams(window.location.search).get("tag");
            navigateToTag(ct || "daily");
        });
        window.addEventListener("scroll", function() {
            var arrow = document.getElementById("scroll-arrow");
            if (window.scrollY > 150) { arrow.style.opacity = "0"; arrow.style.transition = "opacity 0.3s"; }
            else { arrow.style.opacity = ""; arrow.style.transition = ""; }
        });
        initRouter(books);
    } catch (e) {
        console.error("加载失败", e);
        document.body.innerHTML = "<div style=\\"text-align:center;margin-top:50px;\\">加载失败，请刷新页面</div>";
    }
});
`;

const html = "<!DOCTYPE html>\n<html lang=\"zh-CN\">\n<head>\n<meta charset=\"UTF-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no\">\n<title>书方</title>\n<style>\n" + css + "\n</style>\n</head>\n<body>\n" + body + "\n<script>\nvar BOOKS = " + JSON.stringify(books) + ";\n" + js + "\n</script>\n</body>\n</html>";

fs.writeFileSync("D:/tool/suibian/书方.html", html, "utf-8");
console.log("✅ 书方.html 已生成, 大小:", (fs.statSync("D:/tool/suibian/书方.html").size / 1024).toFixed(0), "KB");
